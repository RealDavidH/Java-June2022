package com.dhollinger.omikiuji;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmikiujiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmikiujiApplication.class, args);
	}

}
