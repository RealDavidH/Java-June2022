package com.dhollinger.javaExam.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dhollinger.javaExam.models.Name;

@Repository
public interface NameRepo extends CrudRepository<Name, Long>{
	List<Name> findAll();
}
