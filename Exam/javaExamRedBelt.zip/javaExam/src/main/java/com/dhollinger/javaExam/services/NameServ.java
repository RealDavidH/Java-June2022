package com.dhollinger.javaExam.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhollinger.javaExam.models.Name;
import com.dhollinger.javaExam.repos.NameRepo;

@Service
public class NameServ {
	@Autowired
	private NameRepo repo;
	
	public NameServ(NameRepo repo) {
		this.repo = repo;
	}
	
	public List<Name> getAll(){
		return repo.findAll();
	}
	
	public Name getOne(Long id) {
		Optional<Name> opUser = repo.findById(id);
		if(!opUser.isPresent()) {
			return null;
		}
		return opUser.get();
	}
	
	public Name saveOne(Name name) {
		return repo.save(name);
	}
	public void deleteOne(Long id) {
		repo.deleteById(id);
	}
}
