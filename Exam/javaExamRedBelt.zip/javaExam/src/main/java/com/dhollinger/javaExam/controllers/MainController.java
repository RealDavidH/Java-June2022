package com.dhollinger.javaExam.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhollinger.javaExam.services.NameServ;
import com.dhollinger.javaExam.services.UserServ;

@Controller
public class MainController {
	private final UserServ userServ;
	private final NameServ nameServ;
	
	public MainController(UserServ serv1, NameServ serv2) {
		this.nameServ = serv2;
		this.userServ = serv1;
	}
	
	@RequestMapping("/home")
	public String renderHome(Model model, HttpSession session) {
		if(session.getAttribute("uuid") == null) {
			return "redirect:/";
		}
		model.addAttribute("sessionUser", userServ.getOne((Long) session.getAttribute("uuid")));
		model.addAttribute("allName", nameServ.getAll());
		return "index.jsp";
	}
}
