public class Test{
    public static void main(String[] args){
        Puzzling puzzle = new Puzzling();
        System.out.println(puzzle.rollTenRolls());
        System.out.println(puzzle.generatePassword(100));
        System.out.print(puzzle.getRandomLetter());
        
    }
}