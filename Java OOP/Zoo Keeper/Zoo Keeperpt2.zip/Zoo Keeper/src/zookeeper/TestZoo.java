package zookeeper;

public class TestZoo {

	public static void main(String[] args) {
		Gorilla orge = new Gorilla();
		orge.throwSomething();
		orge.throwSomething();
		orge.throwSomething();
		orge.eatBananas();
		orge.eatBananas();
		orge.climbTree();
		Bat gary = new Bat();
		gary.attackTown();
		gary.attackTown();
		gary.attackTown();
		gary.eatHumans();
		gary.eatHumans();
		gary.fly();
		gary.fly();
		orge.displayEnergy();
		gary.displayEnergy();
	}

}
