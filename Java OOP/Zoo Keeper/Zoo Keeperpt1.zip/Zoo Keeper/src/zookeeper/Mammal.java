package zookeeper;

public class Mammal {
	protected int energy = 100;
	
	
	public void displayEnergy() {
		System.out.println(this.energy);
	}
}
