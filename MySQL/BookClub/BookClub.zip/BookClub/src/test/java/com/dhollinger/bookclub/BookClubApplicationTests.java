package com.dhollinger.bookclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookClubApplicationTests {

	@Test
	void contextLoads() {
	}

}
